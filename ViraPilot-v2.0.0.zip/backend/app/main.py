from fastapi import FastAPI
app = FastAPI(title='ViraPilot v2.0.0')

@app.get('/')
def root():
    return {'message':'ViraPilot API Running'}
